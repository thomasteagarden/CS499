from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """
    CRUD operations for Animal collection in MongoDB
    """

    def __init__(self, USER, PASSWORD, HOST, PORT, DB, COL):
        """
        Initialize the MongoClient and connect to the specified database and collection.
        """
        self.client = MongoClient(f'mongodb://{USER}:{PASSWORD}@{HOST}:{PORT}')
        self.database = self.client[DB]
        self.collection = self.database[COL]
    
    # Create method to implement the C in CRUD
    def create(self, data):
        """
        Insert a document into the specified MongoDB database and collection.
        Return True if successful insert, else False.
        """
        if data is not None:
            result = self.collection.insert_one(data)
            return True if result.inserted_id else False
        else:
            raise Exception("Nothing to save because data parameter is empty")
   
    # Read method to implement in R in CRUD
    def read(self, query):
        """
        Query for documents from the specified MongoDB database and collection.
        Return the result in a list if the command is successful, else an empty list.
        """
        cursor = self.collection.find(query)
        result = [document for document in cursor]
        return result
    
    # Update method to implement the U in CRUD.
    def update(self, initial, change):
        if initial is not None:
            if self.database.animals.count_documents(initial, limit = 1) != 0:
                update_result = self.database.animals.update_many(initial, {"$set": change})
                result = update_result.raw_result
            else:
                result = "No document was found"
            return result
        else:
            raise Exception("Nothing to update, because data parameter is empty")

    # Delete method to implement the D in CRUD.
    def delete(self, remove):
        if remove is not None:
            if self.database.animals.count_documents(remove, limit = 1) != 0:
                delete_result = self.database.animals.delete_many(remove)
                result = delete_result.raw_result
            else:
                result = "No document was found"
            return result
        else:
            raise Exception("Nothing to delete, because data parameter is empty")